#!/bin/sh

# Set up initial cardgen environment.

cd faces/1/
cp ../../pips/1/S.png SA.png

cd ..
mkdir 2
cd 2/
cp ../../pips/2/S.png SA.png
cp ../1/CJ.png .
cp ../1/CK.png .
cp ../1/CQ.png .
cp ../1/DJ.png .
cp ../1/DK.png .
cp ../1/DQ.png .
cp ../1/HJ.png .
cp ../1/HK.png .
cp ../1/HQ.png .
cp ../1/SJ.png .
cp ../1/SK.png .
cp ../1/SQ.png .

cd ../../indices/

mkdir 2
mkdir 3

cd 1/

for card in '2' '3' '4' '5' '6' '7' '8' '9' '10' 'A' 'J' 'K' 'Q' 'S' ''
do
	file=D$card.png
	if [ -e "$file" ]
	then
		convert $file -fuzz 25% -fill 'rgb(0,0,0)' -opaque 'rgb(212,0,0)' C$card.png
		cp $file ../2/
		convert $file -fuzz 25% -fill 'rgb(255,255,255)' -opaque 'rgb(212,0,0)' ../2/C$card.png
		convert $file -fuzz 25% -fill 'rgb(226,207,0)' -opaque 'rgb(212,0,0)' ../3/C$card.png
		convert $file -fuzz 25% -fill 'rgb(19,31,103)' -opaque 'rgb(212,0,0)' ../3/D$card.png
		cp $file ../3/H$card.png
		cp C$card.png ../3/S$card.png
	fi
done

cd ../../pips/2/
cp ../1/D.png .
cp ../1/DS.png .
cp ../1/H.png .
cp ../1/HS.png .

cd ../../pips/3/
cp ../1/H.png .
cp ../1/S.png .
