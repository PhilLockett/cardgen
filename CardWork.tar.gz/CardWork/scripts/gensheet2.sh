#!/bin/bash

# A POSIX variable
OPTIND=1         # Reset in case getopts has been used previously in the shell.

# Initialize our own variables:
width=380
height=532
boarder=4

file='testsheet2'

while getopts "w:h:b:f:" opt; do
    case "$opt" in
    w)  width=$OPTARG
        ;;
    h)  height=$OPTARG
        ;;
    b)  boarder=$OPTARG
        ;;
    f)  file="$OPTARG"
        ;;
    esac
done

shift $((OPTIND-1))

[ "$1" = "--" ] && shift


xp[0]=$boarder
xp[1]=$((xp[0]+$width+$boarder))
xp[2]=$((xp[1]+$width+$boarder))
xp[3]=$((xp[2]+$width+$boarder))
xp[4]=$((xp[3]+$width+$boarder))
xp[5]=$((xp[4]+$width+$boarder))
xp[6]=$((xp[5]+$width+$boarder))
xp[7]=$((xp[6]+$width+$boarder))


yp[0]=$boarder
yp[1]=$((yp[0]+$height+$boarder))
yp[2]=$((yp[1]+$height+$boarder))
yp[3]=$((yp[2]+$height+$boarder))
yp[4]=$((yp[3]+$height+$boarder))
yp[5]=$((yp[4]+$height+$boarder))
yp[6]=$((yp[5]+$height+$boarder))
yp[7]=$((yp[6]+$height+$boarder))
yp[8]=$((yp[7]+$height+$boarder))

	convert -size ${xp[7]}x${yp[8]} xc:transparent  \
		-fill white -stroke black -strokewidth 2 \
		-draw "image over ${xp[0]},${yp[0]} $width,$height 'SJoker.png'" \
		-draw "image over ${xp[1]},${yp[0]} $width,$height 'SA.png'" \
		-draw "image over ${xp[2]},${yp[0]} $width,$height 'S2.png'" \
		-draw "image over ${xp[3]},${yp[0]} $width,$height 'S3.png'" \
		-draw "image over ${xp[4]},${yp[0]} $width,$height 'S4.png'" \
		-draw "image over ${xp[5]},${yp[0]} $width,$height 'S5.png'" \
		-draw "image over ${xp[6]},${yp[0]} $width,$height 'S6.png'" \
		-draw "image over ${xp[0]},${yp[1]} $width,$height 'S7.png'" \
		-draw "image over ${xp[1]},${yp[1]} $width,$height 'S8.png'" \
		-draw "image over ${xp[2]},${yp[1]} $width,$height 'S9.png'" \
		-draw "image over ${xp[3]},${yp[1]} $width,$height 'S10.png'" \
		-draw "image over ${xp[4]},${yp[1]} $width,$height 'SJ.png'" \
		-draw "image over ${xp[5]},${yp[1]} $width,$height 'SQ.png'" \
		-draw "image over ${xp[6]},${yp[1]} $width,$height 'SK.png'" \
		-draw "image over ${xp[0]},${yp[2]} $width,$height 'DJoker.png'" \
		-draw "image over ${xp[1]},${yp[2]} $width,$height 'DA.png'" \
		-draw "image over ${xp[2]},${yp[2]} $width,$height 'D2.png'" \
		-draw "image over ${xp[3]},${yp[2]} $width,$height 'D3.png'" \
		-draw "image over ${xp[4]},${yp[2]} $width,$height 'D4.png'" \
		-draw "image over ${xp[5]},${yp[2]} $width,$height 'D5.png'" \
		-draw "image over ${xp[6]},${yp[2]} $width,$height 'D6.png'" \
		-draw "image over ${xp[0]},${yp[3]} $width,$height 'D7.png'" \
		-draw "image over ${xp[1]},${yp[3]} $width,$height 'D8.png'" \
		-draw "image over ${xp[2]},${yp[3]} $width,$height 'D9.png'" \
		-draw "image over ${xp[3]},${yp[3]} $width,$height 'D10.png'" \
		-draw "image over ${xp[4]},${yp[3]} $width,$height 'DJ.png'" \
		-draw "image over ${xp[5]},${yp[3]} $width,$height 'DQ.png'" \
		-draw "image over ${xp[6]},${yp[3]} $width,$height 'DK.png'" \
		-draw "image over ${xp[0]},${yp[4]} $width,$height 'CJoker.png'" \
		-draw "image over ${xp[1]},${yp[4]} $width,$height 'CA.png'" \
		-draw "image over ${xp[2]},${yp[4]} $width,$height 'C2.png'" \
		-draw "image over ${xp[3]},${yp[4]} $width,$height 'C3.png'" \
		-draw "image over ${xp[4]},${yp[4]} $width,$height 'C4.png'" \
		-draw "image over ${xp[5]},${yp[4]} $width,$height 'C5.png'" \
		-draw "image over ${xp[6]},${yp[4]} $width,$height 'C6.png'" \
		-draw "image over ${xp[0]},${yp[5]} $width,$height 'C7.png'" \
		-draw "image over ${xp[1]},${yp[5]} $width,$height 'C8.png'" \
		-draw "image over ${xp[2]},${yp[5]} $width,$height 'C9.png'" \
		-draw "image over ${xp[3]},${yp[5]} $width,$height 'C10.png'" \
		-draw "image over ${xp[4]},${yp[5]} $width,$height 'CJ.png'" \
		-draw "image over ${xp[5]},${yp[5]} $width,$height 'CQ.png'" \
		-draw "image over ${xp[6]},${yp[5]} $width,$height 'CK.png'" \
		-draw "image over ${xp[0]},${yp[6]} $width,$height 'HJoker.png'" \
		-draw "image over ${xp[1]},${yp[6]} $width,$height 'HA.png'" \
		-draw "image over ${xp[2]},${yp[6]} $width,$height 'H2.png'" \
		-draw "image over ${xp[3]},${yp[6]} $width,$height 'H3.png'" \
		-draw "image over ${xp[4]},${yp[6]} $width,$height 'H4.png'" \
		-draw "image over ${xp[5]},${yp[6]} $width,$height 'H5.png'" \
		-draw "image over ${xp[6]},${yp[6]} $width,$height 'H6.png'" \
		-draw "image over ${xp[0]},${yp[7]} $width,$height 'H7.png'" \
		-draw "image over ${xp[1]},${yp[7]} $width,$height 'H8.png'" \
		-draw "image over ${xp[2]},${yp[7]} $width,$height 'H9.png'" \
		-draw "image over ${xp[3]},${yp[7]} $width,$height 'H10.png'" \
		-draw "image over ${xp[4]},${yp[7]} $width,$height 'HJ.png'" \
		-draw "image over ${xp[5]},${yp[7]} $width,$height 'HQ.png'" \
		-draw "image over ${xp[6]},${yp[7]} $width,$height 'HK.png'" \
		+dither -colors 256 \
		$file.png
